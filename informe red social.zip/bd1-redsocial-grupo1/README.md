# Diseño de Base de Datos – Red Social Estudiantil

## Integrantes
- Deimar Copete
- Iván Bolaños

## Descripción
Modelo lógico de la base de datos de una red social estudiantil. Incluye normalización 1FN, 2FN y 3FN, diccionario de datos, relaciones, claves y diagrama lógico.

## Estructura
```text
Tarea2/
├── Informe/
│   └── informe.pdf
└── Video/
    └── video_enlace.txt
```

## Repositorio
Nombre requerido: `bd1-redsocial-grupo1` (reemplazar X por el número del grupo).
